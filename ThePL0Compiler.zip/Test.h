#pragma once

#include <iostream>
#include "GrammarAnalysis.h"

void TestGrammar()
{
	//KH::GrammarSentence<int> gs;
	//gs("A->tGt",1,"B",2);
}

void DoTest(){
	TestGrammar();
}


